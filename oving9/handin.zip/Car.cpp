#include "Car.h"

Car::Car(int seats): freeSeats{seats}{}