#pragma once
#include "std_lib_facilities.h"

void toFile(void);
void fromFile(string filename);

void countChars(string filename);

int intToAscii(int number);